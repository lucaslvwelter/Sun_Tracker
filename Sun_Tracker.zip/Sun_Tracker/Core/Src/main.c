/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include "string.h"
#include "stdlib.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint32_t valorADC1 = 0, valorADC2 = 0;
uint32_t proximoEvento = 0;
int32_t posEncoder = 0, ultimaPosEncoder= 0;
int posServo = 100;
int contManual = 0, press = 0;
float razADC = 0, v1, v2;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
int map(int x, int in_min, int in_max, int out_min, int out_max);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_ADC2_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  HAL_ADC_Start(&hadc1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
  HAL_TIM_OC_Start_IT(&htim3, TIM_CHANNEL_1);
  proximoEvento = __HAL_TIM_GET_COUNTER(&htim3) + 1000;
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, proximoEvento);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(HAL_GPIO_ReadPin(botEncoder_GPIO_Port, botEncoder_Pin) == 0)
	  {
		  if (press == 0) contManual = !contManual;
		  press = 1;
	  }
	  else press = 0;

	  // habilita a movimentação automática da placa
	  if(contManual == 0)
	  {
		  HAL_ADC_Start(&hadc1);
		  HAL_ADC_Start(&hadc2);

		  if(HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY) == HAL_OK)
		  {
			  valorADC1 = HAL_ADC_GetValue(&hadc1);
		  }
		  if(HAL_ADC_PollForConversion(&hadc2, HAL_MAX_DELAY) == HAL_OK)
		  {
			  valorADC2 = HAL_ADC_GetValue(&hadc2);
		  }

		  // calcula a razão entre os LDRs
		  valorADC1 = 4095 - valorADC1;
		  valorADC2 = 4095 - valorADC2;
		  v1 = (float)valorADC1;
		  v2 = (float)valorADC2;
		  razADC = (sqrt(v1) / (sqrt(v1) + sqrt(v2)));

		  // normalização dos valores
		  razADC = (razADC - 0.425) / (0.625 - 0.425);
		  if(razADC < 0) razADC = 0;
		  if(razADC > 1) razADC = 1;

		  // alterando a posição do servo, vai de 120 a 500 (0° a 180°)
		  razADC = 120 + (razADC * 380);
		  posServo = razADC;
		  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, razADC);
	  }
	  // habilita a movimentação manual da placa
	  else
	  {
		  encoderPos = __HAL_TIM_GET_COUNTER(&htim2);
		  if (posEncoder != ultimaPosEncoder)
		  {
			  if ((int32_t)(posEncoder- ultimaPosEncoder) > 0 && posServo <= 480)
			  {
				  // Movimento horário
				  posServo += 20;
			  }
			  else if ((int32_t)(posEncoder - ultimaPosEncoder) < 0 && posServo >= 120)
			  {
				  // Movimento anti-horário
				  posServo -= 20;
			  }
			  ultimaPosEncoder = posEncoder;
		  }
		  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, posServo);
	  }
	  HAL_Delay(50);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM3 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
	{
		// lê posição atual do servo (duty cycle)
		float pos = __HAL_TIM_GET_COMPARE(&htim1, TIM_CHANNEL_1);

		// envia o relatório a cada 0.1 segundo
		char buffer[32];
		int angulo = map(pos, 500, 120, 0, 180);
		sprintf(buffer, "{\"angulo\": %i}\n\r", angulo);
		HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);

		// agenda próxima captura (0.1 segundo depois)
		proximoEvento += 1000;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, proximoEvento);
	}
}

int map(int x, int in_min, int in_max, int out_min, int out_max)
{
	return ((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
